package MyOwnAutomations;

import org.testng.annotations.Test;

public class Amazon {

    @Test
    public void validateTitle(){

    }
}
